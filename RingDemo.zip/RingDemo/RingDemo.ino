#include <Adafruit_NeoPixel.h>

#define PIN 25
#define POT A0

Adafruit_NeoPixel ring = Adafruit_NeoPixel(16, PIN, NEO_GRB + NEO_KHZ800); // 16 LEDs

void setup() {
  ring.begin();
  ring.setBrightness(32); // set a low brightness
  ring.clear(); // clear all pixels
  ring.show();
}

void wipe(unsigned long color) {
  for(int i=0;i<ring.numPixels();i++) {
    ring.setPixelColor(i, color);
    ring.show();
    delay(100);
  }
}

void loop() {
  wipe(0xFF0000); // red, 0xFF0000 is equivalent to ring.Color(255,0,0);
  wipe(0x00FF00); // green
  wipe(0x0000FF); // blue
  rainbow();
  rainbowCycle();
}

void rainbow() {
  int i, j;
  for(j=0; j<256; j++) {
    for(i=0; i<ring.numPixels(); i++) {
      ring.setPixelColor(i, Wheel((i+j) & 255));
    }
    ring.show();
    delay(20);
  }
}

void rainbowCycle() {
  int i, j;
  for(j=0; j<256*3; j++) { // 3 cycles of all colors on wheel
    for(i=0; i< ring.numPixels(); i++) {
      ring.setPixelColor(i, Wheel(((i * 256 / ring.numPixels()) + j) & 255));
    }
    ring.show();
    delay(20);
  }
}

// Input a value 0 to 255 to get a color value.
// The colours are a transition r - g - b - back to r.
uint32_t Wheel(byte WheelPos) {
  WheelPos = 255 - WheelPos;
  if(WheelPos < 85) {
    return ring.Color(255 - WheelPos * 3, 0, WheelPos * 3);
  }
  if(WheelPos < 170) {
    WheelPos -= 85;
    return ring.Color(0, WheelPos * 3, 255 - WheelPos * 3);
  }
  WheelPos -= 170;
  return ring.Color(WheelPos * 3, 255 - WheelPos * 3, 0);
}

